
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "45.150.17.91",
                    port: parseInt(44821)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "EaBPDuNjt8RqA3n",
                    password: "IL6yiHgkzUfyVl9"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    