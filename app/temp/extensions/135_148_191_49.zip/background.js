
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "135.148.191.49",
                    port: parseInt(56786)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "US16402",
                    password: "VQVcKUOs"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    