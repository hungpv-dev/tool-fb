
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "216.93.28.41",
                    port: parseInt(12323)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "14ad5a834ec44",
                    password: "69b04add6d"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    