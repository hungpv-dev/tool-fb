
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "166.1.11.144",
                    port: parseInt(50100)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "sGMcV",
                    password: "u36ttvPm"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    