
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "207.135.205.96",
                    port: parseInt(49154)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "LN95LjTsH51ISPL",
                    password: "NSJ3eVEt6NI5eIl"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    