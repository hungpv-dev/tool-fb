
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "207.228.46.59",
                    port: parseInt(41812)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "GGDrSBwhlOfhj9j",
                    password: "9ExDoUxRkGSK4w9"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    