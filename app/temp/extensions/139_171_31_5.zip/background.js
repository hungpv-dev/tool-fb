
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "139.171.31.5",
                    port: parseInt(12323)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "14a3608228eea",
                    password: "9236286409"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    