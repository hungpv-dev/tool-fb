
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "207.228.22.249",
                    port: parseInt(43152)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "FdaO6kZpIL0h5YN",
                    password: "kEmbsc5VNZiCpP0"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    