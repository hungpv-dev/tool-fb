
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "139.171.33.77",
                    port: parseInt(12323)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "14a85cd32c924",
                    password: "e1a2fc08e8"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    