
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "207.228.20.73",
                    port: parseInt(44615)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "0EyBy7NQP40qr1q",
                    password: "ApDaXFpuG9ulBxN"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    