
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "216.93.2.8",
                    port: parseInt(42863)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "xH0PDuaRt7tzcyV",
                    password: "bsCbSTAYMZCagU3"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    