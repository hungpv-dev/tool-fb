
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "45.150.19.87",
                    port: parseInt(46211)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "CsfnM1a1CwsPlIj",
                    password: "BSMOZmk6RqodbOV"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    